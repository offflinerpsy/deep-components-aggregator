import { Router } from 'express';

const searchRouter = Router();

// Моковые данные для тестирования
const mockSearchResults = [
    {
        mpn: "LM317T",
        title: "LM317T, Стабилизатор напряжения +1.2...37В 1.5A [TO-220]",
        manufacturer: "Texas Instruments",
        description: "Регулируемый стабилизатор напряжения положительного напряжения",
        package: "TO-220",
        packaging: "Туба",
        regions: ["EU", "US"],
        stock_total: 150,
        price_min: 25.50,
        price_min_currency: "USD",
        price_min_rub: 2142,
        image: "https://static.chipdip.ru/lib/413/DOC005413067.jpg",
        product_url: "https://www.chipdip.ru/product/lm317t-stabilizator-napryazheniya-1.2-37v-1.5a-hgsemi-9001130283",
        source: "chipdip"
    },
    {
        mpn: "1N4148W-TP",
        title: "1N4148W-TP, Диод быстрый переключающий 100V 200mA [SOD-123]",
        manufacturer: "Vishay",
        description: "Быстрый переключающий диод общего назначения",
        package: "SOD-123",
        packaging: "Лента",
        regions: ["EU", "ASIA"],
        stock_total: 5000,
        price_min: 0.15,
        price_min_currency: "USD",
        price_min_rub: 13,
        image: "https://static.chipdip.ru/lib/123/DOC001123456.jpg",
        product_url: "https://www.chipdip.ru/product/1n4148w-tp-diod-bystryy-pereklyuchayushchiy-100v-200ma-vishay-9001234567",
        source: "chipdip"
    },
    {
        mpn: "BC547B",
        title: "BC547B, Транзистор биполярный NPN 45V 100mA [TO-92]",
        manufacturer: "ON Semiconductor",
        description: "Биполярный NPN транзистор общего назначения",
        package: "TO-92",
        packaging: "Туба",
        regions: ["EU", "US", "ASIA"],
        stock_total: 2500,
        price_min: 0.08,
        price_min_currency: "USD",
        price_min_rub: 7,
        image: "https://static.chipdip.ru/lib/789/DOC001789012.jpg",
        product_url: "https://www.chipdip.ru/product/bc547b-tranzistor-bipolyarnyy-npn-45v-100ma-on-semiconductor-9007890123",
        source: "promelec"
    }
];

// Эндпоинт поиска
searchRouter.get('/', (req, res) => {
    try {
        const query = req.query.q;
        
        if (!query) {
            return res.status(400).json({ 
                error: 'Параметр q обязателен',
                message: 'Укажите поисковый запрос в параметре q'
            });
        }
        
        // Фильтруем моковые данные по запросу
        const filteredResults = mockSearchResults.filter(item => 
            item.mpn.toLowerCase().includes(query.toLowerCase()) ||
            item.title.toLowerCase().includes(query.toLowerCase()) ||
            item.manufacturer.toLowerCase().includes(query.toLowerCase()) ||
            item.description.toLowerCase().includes(query.toLowerCase())
        );
        
        // Логируем запрос
        console.log(`🔍 Search request: "${query}" -> ${filteredResults.length} results`);
        
        res.json(filteredResults);
        
    } catch (error) {
        console.error('Ошибка в search API:', error);
        res.status(500).json({ 
            error: 'Внутренняя ошибка сервера',
            message: 'Произошла ошибка при обработке запроса поиска'
        });
    }
});

export default searchRouter;
