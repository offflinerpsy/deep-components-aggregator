import fs from 'fs';
import path from 'path';

// Определяем путь к файлу кэша в корне проекта
const cachePath = path.join(process.cwd(), 'cache.json');

class CacheService {
  constructor() {
    this.cache = new Map();
    this.loadCache();
    // Очищаем устаревшие записи при старте
    this.cleanExpired();
  }

  loadCache() {
    if (fs.existsSync(cachePath)) {
      try {
        const data = fs.readFileSync(cachePath, 'utf8');
        const parsed = JSON.parse(data);
        this.cache = new Map(parsed);
        console.log(`📦 Cache loaded: ${this.cache.size} entries`);
      } catch (error) {
        console.warn('Failed to load cache file:', error.message);
        this.cache = new Map();
      }
    } else {
      console.log('📦 No cache file found, starting fresh');
    }
  }

  saveCache() {
    try {
      const data = JSON.stringify(Array.from(this.cache.entries()));
      fs.writeFileSync(cachePath, data, 'utf8');
      console.log(`💾 Cache saved: ${this.cache.size} entries`);
    } catch (error) {
      console.warn('Failed to save cache file:', error.message);
    }
  }

  cleanExpired() {
    const now = Date.now();
    let cleaned = 0;
    for (const [key, value] of this.cache.entries()) {
      if (value.expiresAt < now) {
        this.cache.delete(key);
        cleaned++;
      }
    }
    if (cleaned > 0) {
      console.log(`🧹 Cleaned ${cleaned} expired cache entries`);
      this.saveCache();
    }
  }

  get(key) {
    const now = Date.now();
    const item = this.cache.get(key);
    
    if (!item || item.expiresAt < now) {
      if (item) {
        this.cache.delete(key);
        this.saveCache();
      }
      return null;
    }
    
    console.log(`⚡ Cache hit for key: ${key}`);
    return item.value;
  }

  set(key, value, ttlSeconds = 3600) { // TTL по умолчанию 1 час
    const expiresAt = Date.now() + ttlSeconds * 1000;
    this.cache.set(key, { value, expiresAt });
    this.saveCache();
    console.log(`💾 Cached key: ${key} (TTL: ${ttlSeconds}s)`);
  }

  // Метод для получения статистики кэша
  getStats() {
    const now = Date.now();
    let valid = 0;
    let expired = 0;
    
    for (const [key, value] of this.cache.entries()) {
      if (value.expiresAt < now) {
        expired++;
      } else {
        valid++;
      }
    }
    
    return {
      total: this.cache.size,
      valid,
      expired,
      cacheFile: cachePath
    };
  }
}

export const cacheService = new CacheService();
