// frontend/public/search.js
const qEl = document.getElementById('q');
const grid = document.getElementById('grid');
const stat = document.getElementById('stat');
const zero = document.getElementById('zero');
const preloader = document.getElementById('preloader');
const searchForm = document.getElementById('searchForm');

function card(d) {
  return `
    <div class="card" data-mpn="${d.mpn}">
      <div class="card-header">
        <div>
          <div class="card-title">${d.title || 'Без названия'}</div>
          <div class="card-manufacturer">${d.manufacturer || 'Неизвестный производитель'}</div>
        </div>
        <div class="card-mpn">${d.mpn || 'N/A'}</div>
      </div>
      
      ${d.description ? `<div class="card-description">${d.description}</div>` : ''}
      
      ${d.specs_flat ? `<div class="card-specs">${d.specs_flat}</div>` : ''}
      
      <div class="card-footer">
        <div class="card-price">${d.price || 'Цена по запросу'}</div>
        <div class="card-image">
          ${d.image && d.image !== '/ui/placeholder.svg' ? 
            `<img src="${d.image}" alt="${d.title}" style="width: 100%; height: 100%; object-fit: contain;">` : 
            '📦'
          }
        </div>
      </div>
    </div>
  `;
}

function render(list, query) {
  if (list.length === 0) {
    grid.innerHTML = '';
    stat.style.display = 'none';
    zero.style.display = 'block';
    zero.innerHTML = `
      <h3>🔍 Ничего не найдено</h3>
      <p>По запросу "${query}" ничего не найдено. Попробуйте изменить поисковый запрос.</p>
    `;
    return;
  }
  
  zero.style.display = 'none';
  stat.style.display = 'block';
  document.getElementById('count').textContent = list.length;
  
  grid.innerHTML = list.map(card).join('');
  
  // Добавляем обработчики клика для карточек
  document.querySelectorAll('.card').forEach(cardEl => {
    cardEl.addEventListener('click', () => {
      const mpn = cardEl.dataset.mpn;
      if (mpn) {
        // Можно добавить переход к детальной странице
        console.log('Клик по компоненту:', mpn);
      }
    });
  });
}

async function runSearch(q) {
  if (!q) { 
    render([], ''); 
    return; 
  }
  
  preloader.style.display = 'block';
  grid.innerHTML = '';
  zero.style.display = 'none';
  stat.style.display = 'none';
  
  try {
    const response = await fetch(`/api/search?q=${encodeURIComponent(q)}`);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const json = await response.json();
    
    if (!json.ok) {
      throw new Error(json.error || 'Ошибка API');
    }
    
    render(json.hits || [], q);
  } catch (e) {
    console.error('Ошибка поиска:', e);
    zero.style.display = 'block';
    zero.innerHTML = `
      <h3>❌ Ошибка поиска</h3>
      <p>${e.message}</p>
    `;
  } finally {
    preloader.style.display = 'none';
  }
}

// Обработка формы поиска
searchForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const query = qEl.value.trim();
  runSearch(query);
});

// Обработка ввода в реальном времени (с задержкой)
let searchTimeout;
qEl.addEventListener('input', (e) => {
  clearTimeout(searchTimeout);
  const query = e.target.value.trim();
  
  if (query.length === 0) {
    render([], '');
    return;
  }
  
  // Поиск с задержкой 300мс
  searchTimeout = setTimeout(() => {
    runSearch(query);
  }, 300);
});

// Обработка Enter в поле поиска
qEl.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    clearTimeout(searchTimeout);
    runSearch(qEl.value.trim());
  }
});

// Инициализация
document.addEventListener('DOMContentLoaded', () => {
  // Фокус на поле поиска
  qEl.focus();
  
  // Проверяем, есть ли поисковый запрос в URL
  const urlParams = new URLSearchParams(window.location.search);
  const query = urlParams.get('q');
  if (query) {
    qEl.value = query;
    runSearch(query);
  }
});

// Экспорт для тестирования
window.searchApp = {
  runSearch,
  render,
  card
};

