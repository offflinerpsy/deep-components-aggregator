import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';

const CACHE_DB_PATH = path.resolve('data/cache.db');
const CORPUS_PATH = path.resolve('data/corpus.json');

// Создаем директорию data если не существует
const dataDir = path.dirname(CORPUS_PATH);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

function buildCorpus() {
  console.log('🔍 Построение корпуса для поиска...');
  
  let docs = [];
  console.log('📁 Проверка файлов данных...');
  
  // Пытаемся загрузить из SQLite базы
  if (fs.existsSync(CACHE_DB_PATH)) {
    console.log('📊 Загрузка данных из SQLite базы...');
    const db = new Database(CACHE_DB_PATH);
    
    try {
      const stmt = db.prepare(`
        SELECT 
          mpn,
          title,
          manufacturer,
          description,
          technical_specs,
          package,
          packaging,
          price_min_rub,
          image,
          product_url
        FROM products 
        WHERE mpn IS NOT NULL AND title IS NOT NULL
      `);
      
      const rows = stmt.all();
      docs = rows.map(row => ({
        id: row.mpn,
        title: row.title || '',
        mpn: row.mpn || '',
        manufacturer: row.manufacturer || '',
        description: row.description || '',
        specs_flat: typeof row.technical_specs === 'string' 
          ? row.technical_specs 
          : JSON.stringify(row.technical_specs || {}),
        url: row.product_url || '',
        image: row.image || '/ui/placeholder.svg',
        price: row.price_min_rub ? `${row.price_min_rub} ₽` : 'Цена по запросу'
      }));
      
      console.log(`✅ Загружено ${docs.length} записей из SQLite`);
    } catch (error) {
      console.error('❌ Ошибка чтения SQLite:', error.message);
    } finally {
      db.close();
    }
  }
  
  // Если SQLite не работает, пытаемся загрузить из JSON файлов
  if (docs.length === 0) {
    console.log('📄 Попытка загрузки из JSON файлов...');
    
    const jsonFiles = [
      'data/seed-LM317T.json',
      'data/seed-1N4148W-TP.json',
      'data/seed-index.json'
    ];
    
    for (const filePath of jsonFiles) {
      if (fs.existsSync(filePath)) {
        try {
          const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
          let items = [];
          
          if (Array.isArray(data)) {
            items = data;
          } else if (data.items && Array.isArray(data.items)) {
            items = data.items;
          } else if (data.hits && Array.isArray(data.hits)) {
            items = data.hits;
          }
          
          const processedItems = items.map(item => ({
            id: item.mpn || item.id || Math.random().toString(36),
            title: item.title || '',
            mpn: item.mpn || '',
            manufacturer: item.manufacturer || '',
            description: item.description || '',
            specs_flat: typeof item.technical_specs === 'string' 
              ? item.technical_specs 
              : JSON.stringify(item.technical_specs || {}),
            url: item.product_url || item.url || '',
            image: item.image || '/ui/placeholder.svg',
            price: item.price_min_rub ? `${item.price_min_rub} ₽` : 'Цена по запросу'
          }));
          
          docs.push(...processedItems);
          console.log(`✅ Загружено ${processedItems.length} записей из ${filePath}`);
        } catch (error) {
          console.error(`❌ Ошибка чтения ${filePath}:`, error.message);
        }
      }
    }
  }
  
  // Если ничего не загружено, создаем тестовые данные
  if (docs.length === 0) {
    console.log('🧪 Создание тестовых данных...');
    docs = [
      {
        id: 'LM317T',
        title: 'LM317T STMicroelectronics Linear Voltage Regulator',
        mpn: 'LM317T',
        manufacturer: 'STMicroelectronics',
        description: 'Adjustable positive voltage regulator, 1.2V to 37V output, 1.5A current',
        specs_flat: 'Package: TO-220, Input: 4V-40V, Output: 1.2V-37V, Current: 1.5A',
        url: '',
        image: '/ui/placeholder.svg',
        price: '15 ₽'
      },
      {
        id: '1N4148',
        title: '1N4148 Fast Switching Diode',
        mpn: '1N4148',
        manufacturer: 'Various',
        description: 'Fast switching diode, 100V reverse voltage, 200mA forward current',
        specs_flat: 'Package: DO-35, Vr: 100V, If: 200mA, Trr: 4ns',
        url: '',
        image: '/ui/placeholder.svg',
        price: '5 ₽'
      }
    ];
  }
  
  // Сохраняем корпус
  fs.writeFileSync(CORPUS_PATH, JSON.stringify(docs, null, 2));
  console.log(`💾 Корпус сохранен в ${CORPUS_PATH}`);
  console.log(`📊 Всего документов: ${docs.length}`);
  
  return docs;
}

// Запускаем если файл выполняется напрямую
console.log('🚀 Запуск скрипта build-corpus.mjs');
buildCorpus();

export { buildCorpus };
