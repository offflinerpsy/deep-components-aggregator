import fs from 'node:fs';
import path from 'node:path';

const CORPUS_PATH = path.resolve('data/corpus.json');

console.log('🔍 Создание простого корпуса...');

// Читаем существующие JSON файлы
const jsonFiles = [
  'data/seed-LM317T.json',
  'data/seed-1N4148W-TP.json', 
  'data/seed-index.json'
];

let docs = [];

for (const filePath of jsonFiles) {
  if (fs.existsSync(filePath)) {
    console.log(`📄 Читаем ${filePath}...`);
    try {
      const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      let items = [];
      
      if (Array.isArray(data)) {
        items = data;
      } else if (data.items && Array.isArray(data.items)) {
        items = data.items;
      } else if (data.hits && Array.isArray(data.hits)) {
        items = data.hits;
      }
      
      const processedItems = items.map(item => ({
        id: item.mpn || item.id || Math.random().toString(36),
        title: item.title || '',
        mpn: item.mpn || '',
        manufacturer: item.manufacturer || '',
        description: item.description || '',
        specs_flat: typeof item.technical_specs === 'string' 
          ? item.technical_specs 
          : JSON.stringify(item.technical_specs || {}),
        url: item.product_url || item.url || '',
        image: item.image || '/ui/placeholder.svg',
        price: item.price_min_rub ? `${item.price_min_rub} ₽` : 'Цена по запросу'
      }));
      
      docs.push(...processedItems);
      console.log(`✅ Обработано ${processedItems.length} записей из ${filePath}`);
    } catch (error) {
      console.error(`❌ Ошибка чтения ${filePath}:`, error.message);
    }
  }
}

// Если ничего не загружено, создаем тестовые данные
if (docs.length === 0) {
  console.log('🧪 Создание тестовых данных...');
  docs = [
    {
      id: 'LM317T',
      title: 'LM317T STMicroelectronics Linear Voltage Regulator',
      mpn: 'LM317T',
      manufacturer: 'STMicroelectronics',
      description: 'Adjustable positive voltage regulator, 1.2V to 37V output, 1.5A current',
      specs_flat: 'Package: TO-220, Input: 4V-40V, Output: 1.2V-37V, Current: 1.5A',
      url: '',
      image: '/ui/placeholder.svg',
      price: '15 ₽'
    },
    {
      id: '1N4148',
      title: '1N4148 Fast Switching Diode',
      mpn: '1N4148',
      manufacturer: 'Various',
      description: 'Fast switching diode, 100V reverse voltage, 200mA forward current',
      specs_flat: 'Package: DO-35, Vr: 100V, If: 200mA, Trr: 4ns',
      url: '',
      image: '/ui/placeholder.svg',
      price: '5 ₽'
    },
    {
      id: 'регулятор',
      title: 'Регулятор напряжения LM317',
      mpn: 'LM317',
      manufacturer: 'STMicroelectronics',
      description: 'Регулятор напряжения с возможностью настройки выходного напряжения',
      specs_flat: 'Корпус: TO-220, Вход: 4В-40В, Выход: 1.2В-37В, Ток: 1.5А',
      url: '',
      image: '/ui/placeholder.svg',
      price: '12 ₽'
    }
  ];
}

// Сохраняем корпус
fs.writeFileSync(CORPUS_PATH, JSON.stringify(docs, null, 2));
console.log(`💾 Корпус сохранен в ${CORPUS_PATH}`);
console.log(`📊 Всего документов: ${docs.length}`);

export { docs };

