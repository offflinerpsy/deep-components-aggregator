import express from 'express';
import compression from 'compression';
import cors from 'cors';
import { loadIndex, query } from './src/search/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(compression());
app.use(cors());

const PORT = process.env.PORT || 9201;
const PUB_PATH = path.resolve(__dirname, 'frontend/public');

app.use(express.static(PUB_PATH));

let IDX;

// API для поиска
app.get('/api/search', async (req, res) => {
  if (!IDX) {
    return res.status(503).json({ 
      error: 'Поисковый индекс еще не загружен.',
      ok: false 
    });
  }
  
  const q = String(req.query.q || '').trim();
  if (q === '') {
    return res.json({ 
      hits: [], 
      count: 0, 
      query: q,
      ok: true 
    });
  }
  
  try {
    const r = await query(IDX, q);
    const hits = r.hits.map(h => h.document);
    res.json({ 
      hits, 
      count: hits.length, 
      query: q,
      ok: true 
    });
  } catch (error) {
    console.error('Ошибка поиска:', error);
    res.status(500).json({ 
      error: 'Внутренняя ошибка поиска',
      ok: false 
    });
  }
});

// API для версии
app.get('/_version', (req, res) => {
  res.json({ 
    ok: true, 
    name: "deep-agg-alpha", 
    version: "0.1.0", 
    ts: Date.now(),
    searchEngine: "Orama"
  });
});

// Главная страница
app.get('/', (req, res) => {
  res.sendFile(path.join(PUB_PATH, 'index.html'));
});

// Страница поиска
app.get('/search', (req, res) => {
  res.sendFile(path.join(PUB_PATH, 'search.html'));
});

// Обработка ошибок
app.use((req, res) => {
  res.status(404).json({ 
    error: 'Страница не найдена',
    ok: false 
  });
});

// Загружаем индекс и только потом запускаем сервер
console.log('🚀 Запуск сервера с умным поиском...');
console.log('📂 Загрузка поискового индекса...');

loadIndex().then(db => {
  if (db) {
    IDX = db;
    console.log('✅ Индекс успешно загружен.');
    app.listen(PORT, () => {
      console.log(`🌐 Сервер запущен на http://localhost:${PORT}`);
      console.log(`🔍 Поиск доступен на http://localhost:${PORT}/search`);
      console.log(`📊 API поиска: http://localhost:${PORT}/api/search?q=регулятор`);
    });
  } else {
    console.error('❌ Не удалось загрузить индекс. Сервер не запущен.');
    process.exit(1);
  }
}).catch(error => {
  console.error('❌ Критическая ошибка загрузки индекса:', error);
  process.exit(1);
});

