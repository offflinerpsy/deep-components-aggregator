import('./src/search/index.mjs').then(m => m.buildAndSaveIndex());

