export default {
  testEnvironment: 'node',
  transform: {},
  testMatch: [
    '**/tests/**/*.spec.js',
    '**/tests/**/*.test.js'
  ]
};
