#!/bin/bash
cd /tmp
unzip -o deploy.zip
rm -rf /opt/deep-agg/*
mkdir -p /opt/deep-agg
cp -r * /opt/deep-agg/
cd /opt/deep-agg
npm install --production
pkill -f 'node server.js' || true
nohup node server.js > server.log 2>&1 &
sleep 3
curl http://127.0.0.1:9201/api/search?q=LM317
